<?php

$conf['smtp_host'] = 'localhost';
$conf['smtp_port'] = 25;
$conf['smtp_ssl']  = '';

$conf['localdomain'] = '';

$conf['auth_user'] = '';
$conf['auth_pass'] = '';


$conf['debug'] = 0;
