<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author alhajr <alhajr300@gmail.com>
 */
$lang['smtp_host']             = 'خادم البريد الصادر SMTP.';
$lang['smtp_ssl']              = 'ما هو نوع التشفير المستخدم عند الاتصال مع ملقم SMTP الخاص بك؟';
$lang['smtp_ssl_o_']          = 'لا شيء';
$lang['auth_user']             = 'إذا كانت المصادقة مطلوبة، ضع اسم المستخدم الخاص بك هنا.';
$lang['auth_pass']             = 'كلمة المرور للمستخدم أعلاه.';
$lang['debug']                 = 'طباعة سجل كامل للاخطأ عند فشل الإرسال؟ تعطيل عندما يعمل كل شيء!';
