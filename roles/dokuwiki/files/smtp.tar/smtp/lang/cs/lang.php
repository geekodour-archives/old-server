<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Pavel Krupička <pajdacz@gmail.com>
 */
$lang['menu']                  = 'Zkouška nastavení SMTP';
$lang['nofrom']                = 'Nenastavili jste možnost \'mailfrom\'. Odesílání e-mailů pravděpodobně selže.';
