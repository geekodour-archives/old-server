<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Søren Birk <soer9648@eucl.dk>
 */
$lang['menu']                  = 'Kontrollér SMTP konfiguration';
$lang['nofrom']                = 'Du konfigurerede ikke \'mailfrom\'-indstillingen. Sending af mails vil højst sandsynligt fejle.';
