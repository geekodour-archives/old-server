<?php

$lang['menu'] = 'Check SMTP configuration';
$lang['nofrom'] = 'You did not configure the \'mailfrom\' option. Sending mails will probably fail.';
