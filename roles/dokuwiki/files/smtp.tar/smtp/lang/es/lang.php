<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Alicia Esponda <aesponda@ieee.org>
 */
$lang['menu']                  = 'Verifica la configuración SMTP';
$lang['nofrom']                = 'No configuraste la opción "correo de envío".  Probablemente fallará el envío de correos electrónicos.';
