<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hideaki SAWADA <chuno@live.jp>
 */
$lang['menu']                  = 'SMTP 設定の確認';
$lang['nofrom']                = '\'mailfrom\' オプションを設定していません。メール送信は、おそらく失敗します。';
