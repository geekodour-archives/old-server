<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Myeongjin <aranet100@gmail.com>
 */
$lang['menu']                  = 'SMTP 설정 확인';
$lang['nofrom']                = '\'mailfrom\' 옵션이 설정되지 않았습니다. 메일 보내기는 아마 실패할 것입니다.';
