<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Gerrit Uitslag <Klapinklapin@gmail.com>
 */
$lang['menu']                  = 'SMTP configuratie controleren';
$lang['nofrom']                = 'Je hebt niet de \'mailfrom\' optie geconfigureerd. Het versturen van e-mail zal waarschijnlijk mislukken.';
