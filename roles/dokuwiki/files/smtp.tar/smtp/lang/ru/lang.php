<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Artem Trutko <trutko@facebook.com>
 */
$lang['menu']                  = 'Проверка SMTP конфигурации';
$lang['nofrom']                = 'Вы не указали получателя. Отправка письма вряд ли получится.';
