<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Tor Härnqvist <tor@harnqvist.se>
 */
$lang['menu']                  = 'Kontrollera SMTP-konfiguration';
$lang['nofrom']                = 'Du konfigurerade inte \'mailform\'-alternativet. E-postutskick kommer troligen inte fungera.';
